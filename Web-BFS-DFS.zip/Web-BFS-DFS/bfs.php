<?php

// Retrieve form data
$startingNode = $_POST['startingNode'];
$goalNode = $_POST['goalNode'];
$graph = json_decode($_POST['graph'], true);

// Implement BFS algorithm
function bfs($graph, $startingNode, $goalNode) {
    $visited = [];
    $queue = [];
    $path = [];

    array_push($queue, $startingNode);
    $visited[$startingNode] = true;

    while (!empty($queue)) {
        $currentNode = array_shift($queue);
        echo "Current node: " . $currentNode . "<br>"; // Debug statement
        if ($currentNode === $goalNode) {
            // If goal node found, return the path
            $path[] = $currentNode;
            while (isset($path[$currentNode]['parent'])) {
                $currentNode = $path[$currentNode]['parent'];
                array_unshift($path, $currentNode);
            }
            return $path;
        }

        if (isset($graph[$currentNode])) {
            foreach ($graph[$currentNode] as $neighbor) {
                if (!isset($visited[$neighbor])) {
                    $visited[$neighbor] = true;
                    array_push($queue, $neighbor);
                    $path[$neighbor] = ['parent' => $currentNode];
                }
            }
        }
    }

    return []; // If no path found
}

// Call BFS algorithm
$path = bfs($graph, $startingNode, $goalNode);

// Save result to MySQL database
$servername = "localhost";
$username = "root";
$password = ""; // Enter your MySQL password here
$database = "registerbfsdfs"; // Enter your database name here
$table = "bfs"; // Enter your table name here

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and execute SQL query to save the result
$sql = "INSERT INTO $table (startingNode, goalNode, result) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);

// Bind parameters
$stmt->bind_param("sss", $startingNode, $goalNode, $result);

// Implode the path array to create the result
$result = implode(" ", $path);

// Execute the statement
if ($stmt->execute()) {
    echo "Result saved successfully<br>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$stmt->close();
$conn->close();

// Output result
if (!empty($path)) {
    echo "Path found: " . implode(" ", $path);
} else {
    echo "No path found";
}

?>
