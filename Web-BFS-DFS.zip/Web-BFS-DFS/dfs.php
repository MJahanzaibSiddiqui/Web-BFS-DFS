<?php

// Retrieve form data
$startingNode = trim($_POST['startingNode'], '"');
$goalNode = trim($_POST['goalNode'], '"');
$graph = json_decode($_POST['graph'], true);

// Implement DFS algorithm
function dfs($graph, $visited, $startingNode, $goalNode, &$result) {
    $visited[$startingNode] = true;
    $result .= $startingNode . " ";
    if ($startingNode === $goalNode) {
        return true;
    }
    foreach ($graph[$startingNode] as $neighbor) {
        if (!isset($visited[$neighbor])) {
            if (dfs($graph, $visited, $neighbor, $goalNode, $result)) {
                return true;
            }
        }
    }
    return false;
}

$result = "";
$visited = [];
dfs($graph, $visited, $startingNode, $goalNode, $result);

// Save result to MySQL database
// Replace 'your_host', 'your_username', 'your_password', 'your_database', and 'your_table_name' with your actual MySQL database credentials and table name

$servername = "localhost";
$username = "root";
$password = "";
$database = "registerbfsdfs";
$table = "dfs";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and execute SQL query to save the result
$sql = "INSERT INTO $table (startingNode, goalNode, result) VALUES ('$startingNode', '$goalNode', '$result')";

if ($conn->query($sql) === TRUE) {
    echo "Result saved successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

// Output result
echo $result;

?>
