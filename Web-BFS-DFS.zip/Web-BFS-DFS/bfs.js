document.getElementById("bfsForm").addEventListener("submit", function (event) {
    event.preventDefault();

    const startingNode = document.getElementById("startingNode").value;
    const goalNode = document.getElementById("goalNode").value;
    const graph = JSON.parse(document.getElementById("graph").value);

    // Send BFS request to the server
    sendBFSRequest(startingNode, goalNode, graph);
});

function sendBFSRequest(startingNode, goalNode, graph) {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "bfs.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            const result = xhr.responseText;
            displayBFSResult(result);
        }
    };
    const data = "startingNode=" + encodeURIComponent(startingNode) +
        "&goalNode=" + encodeURIComponent(goalNode) +
        "&graph=" + encodeURIComponent(JSON.stringify(graph));
    xhr.send(data);
}

function displayBFSResult(result) {
    const resultContainer = document.getElementById("result");
    resultContainer.innerHTML = result;
}
