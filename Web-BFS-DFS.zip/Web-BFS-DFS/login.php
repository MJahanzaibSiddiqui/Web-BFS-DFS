<?php

$conn = mysqli_connect('localhost', 'root','','registerbfsdfs');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data

$username = $_POST['username'];
$password = $_POST['password'];

// Insert data into database
$sql = "INSERT INTO loginusers ( username, password)
        VALUES ('$username',   '$password')";

if (mysqli_query($conn, $sql)) {
    // Redirect to bfsdfs.html
    header("Location: bfsdfs.html");
    exit();
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
