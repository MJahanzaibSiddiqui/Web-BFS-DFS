<?php
// $servername = "localhost";
// $username = "root";
// $password = "";
// $database = "registerbfsdfs";

// Create connection
// $conn = new mysqli($servername, $username, $password, $$database);
$conn = mysqli_connect('localhost', 'root','','registerbfsdfs');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];
$createpassword = $_POST['createpassword'];

// Insert data into database
$sql = "INSERT INTO users (firstname, lastname, email, createpassword)
        VALUES ('$firstname', '$lastname', '$email', '$createpassword')";

if (mysqli_query($conn, $sql)) {
    // Redirect to bfsdfs.html
    header("Location: loginform.html");
    exit();
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
