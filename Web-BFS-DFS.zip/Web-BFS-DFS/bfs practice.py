
graph= {
    'A':['B','D'],
    'B':['C','E'],
    'D':['E','G','H'],
    'E':['F'],
    'G':['H'],
}
VN=[]
q=[]
def bfs( VN, graph, starting_node, goal_node):
    VN.append(starting_node)
    q.append(starting_node)
    while q:
        m=q.pop(0)
    print (m, end="") 
    if m==goal_node :
       return   
    for neighbours in graph[m]:
        if neighbours not in VN :
            VN.append(neighbours) 
            q.append(neighbours)
print("here is the bfs")
print(VN, graph,'A','G')
            
        
   