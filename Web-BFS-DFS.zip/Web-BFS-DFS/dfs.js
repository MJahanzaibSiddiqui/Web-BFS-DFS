document.getElementById("dfsForm").addEventListener("submit", function(event) {
    event.preventDefault();
    
    const startingNode = document.getElementById("startingNode").value;
    const goalNode = document.getElementById("goalNode").value;
    const graph = JSON.parse(document.getElementById("graph").value);
    
    // Call PHP script using AJAX
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "dfs.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            document.getElementById("result").innerHTML = xhr.responseText;
        }
    };
    const data = "startingNode=" + startingNode + "&goalNode=" + goalNode + "&graph=" + JSON.stringify(graph);
    xhr.send(data);
});
