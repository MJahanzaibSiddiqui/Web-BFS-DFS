<?php

$conn = mysqli_connect('localhost', 'root','','registerbfsdfs');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data

$name = $_POST['name'];
$email = $_POST['email'];
$query = $_POST['query'];
// Insert data into database
$sql = "INSERT INTO contacts ( name,email, query)
        VALUES ('$name', '$email','$query')";

if (mysqli_query($conn, $sql)) {
    // Redirect to bfsdfs.html
    header("Location: thankyou.html");
    exit();
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
